#!/bin/sh

# actually compile a edje file with all the gfx etc.
edje_cc $@ -id . -fd . icon.edc icon.eapp

# add eapp properties to the file - they are ALL optional EXCEPT name and exe
# and exe is optional for directory .eapp files
enlightenment_eapp \
icon.eapp \
-set-name "Application Name" \
-set-generic "Generic name" \
-set-comment "Comment on what this application does" \
-set-exe "execute_line" \
-set-win-name "window_name" \
-set-win-class "window_class"
